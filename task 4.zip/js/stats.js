let stats =
{
 "total" : 0,
 "total_votes" : 0,
 "democrat" : 0,
 "demo_Mvotes" : 0,
 "demo_votes_party" : 0,
 "d_total_votes" : 0,
 "republican" : 0,
 "repu_Mvotes" : 0,
 "r_total_votes" :0,
 "repu_votes_party" : 0,
 "independent" : 0,
 "inde_Mvotes" : 0,
 "inde_votes_party" : 0,
 "i_total_votes" : 0,
 "least_engaged" : [],
 "most_engaged" : [],
 "most_loyal" : [],
 "least_loyal" : [],
}

