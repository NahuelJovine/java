console.log ("starting javascript...");
//javascript bassics 
//ejercicio 1
let myName = "Nahuel";
console.log (myName);
//ejercicio 2
let age = 17;
console.log (age);
//ejercicio 3
let ingnasiAge = 32
let ageDiff = age - ingnasiAge
console.log (ageDiff)
//ejercicio 4
if (age>21) {
	console.log("You are older than 21")
}
else {
	console.log("You are not older than 21")
}
//ejrcicio 5
if (ingnasiAge>age) {
	console.log("Ignasi is older than you")
}
else if (ingnasiAge<age) {
	console.log("Ignasi is younger than you")
}
else {
	console.log("You have the same age as Ignasi")
}
//array ejercicio 1
let students = ["Branko","Rodri","Alan","Lean","Diego","Ariel","Nahuel"];
students.sort()

for (let i =0 ; i<students.length; i++) {
	console.log (students[i])
}
//ejercicio 2
let studentsAge = [17 , 18 ,19 , 20 , 21 , 22 , 23 ,24]

for (let i =0 ; i<studentsAge.length; i++) {
	if (studentsAge[i] %2 ==0){
		console.log (studentsAge[i])
	}
}
//ejercicio 3
let arrayEx = [4 ,5 ,2 ,9 ,36 ,13] 
function arrayMin (array){
	let min =array[0]
	for (let i =0 ; i<array.length; i++){
		if (array[i]<min){
			min = array[i]
		}
	}
	console.log (min)
}
arrayMin (arrayEx)
//ejercicio 4
function arraymax (array){
	let max =array[0]
	for (let i =0 ; i<array.length; i++){
		if (array[i]>max){
			max=array[i]
		}
	}
	console.log (max)
}
arraymax (arrayEx)
//ejercicio 5
function print (array,index){
	let variable = array[index]

	console.log (variable)
}
print (arrayEx,5)
//ejercicio 6
let dobles = [2,3,5,2,6,4,7,1,8,5,9,10,4,15,2,3]
function double (array){
	let repeat = []
	for (let i=0 ; i<array.length; i++){
		for (let j=i+1 ; j<array.length; j++){
			if (array[i] == array[j]){
				if (repeat.indexOf(array[i]) ==-1){
					repeat.push(array[i]) 
				}
			}
		}
	}
console.log (repeat)
}
double (dobles)
//ejercicio 7
 let myColor = ["Red", "Green", "White", "Black"];
 function color (array){
let colors = myColor.toString();
console.log (colors)
}
color (myColor)
//string ejercicio 1
let string1 = "32443"
function reverse (string){
	let split = string.split("")
	let Reverse = split.reverse()
	let join = Reverse.join("")
	
	console.log(join)	
}
reverse (string1)
//ejercicio 2
let abc = "webmaster"
function ordenada(string){
	let split = string.split("")
	let sort = split.sort()
	let join = sort.join("")
	console.log(join)
	
}
ordenada (abc)
//ejercicio 3
let mayus ="prince of persia"
function mayuscula (string){
	let split = string.split(" ")
	let aux = []
	for (let i =0 ; i<split.length ; i++) {
		aux.push(split[i].charAt(0).toUpperCase()+
		split[i].slice(1) )
	}
	let join = aux.join(" ")
	console.log(join)
}
mayuscula(mayus)
//ejercicio 4
let large = "Web Development Tutorial"
function larga (string){
	let big =""
	let vec = string.split(" ")
	vec.forEach(
		function(palabra){
			if (palabra.length>big.length){
				big=palabra
			}
		})
	console.log(big)
}
larga (large)