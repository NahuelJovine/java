const body = document.querySelector("tbody") 
const members = data.results[0].members
members.forEach(members=>{
	if(members.middle_name==null){
		members.middle_name=" ";
	}
	let row = body.insertRow(-1);
	row.innerHTML= "<td><a href='"+members.url+"'>"+members.last_name+'  '+members.first_name+'  '+members.middle_name+"</a></td><td>"+members.party+"</td><td>"+members.state+"</td><td>"+members.seniority+"</td><td>"+members.votes_with_party_pct+"</td>"
} 
)